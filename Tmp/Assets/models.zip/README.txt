Battle Damaged Sci-fi Helmet - PBR by theblueturtle_, published under a Creative Commons Attribution-NonCommercial license

https://sketchfab.com/models/b81008d513954189a063ff901f7abfe4
